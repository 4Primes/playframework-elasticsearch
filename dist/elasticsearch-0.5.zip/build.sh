play deps --sync
play build-module
